import 'package:flutter/material.dart';

import '../../core/theme/kainph_theme.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '🍴 KainPH',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              color: KainPHTheme.success.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Row(
              children: [
                Icon(
                  Icons.cloud_off,
                  size: 16,
                  color: KainPHTheme.success,
                ),
                SizedBox(width: 6),
                Text(
                  'Offline',
                  style: TextStyle(
                    color: KainPHTheme.success,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(KainPHTheme.spacingMedium),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Good evening! 👋',
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: KainPHTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Here is your business overview.',
              style: TextStyle(
                color: KainPHTheme.textSecondary,
              ),
            ),
            const SizedBox(height: KainPHTheme.spacingLarge),
            Row(
              children: [
                Expanded(
                  child: _StatCard(
                    title: "Today's Sales",
                    value: '₱0.00',
                    icon: Icons.payments_outlined,
                  ),
                ),
                const SizedBox(width: KainPHTheme.spacingMedium),
                Expanded(
                  child: _StatCard(
                    title: 'Orders',
                    value: '0',
                    icon: Icons.receipt_long_outlined,
                  ),
                ),
              ],
            ),
            const SizedBox(height: KainPHTheme.spacingLarge),
            const Text(
              'Quick Actions',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: KainPHTheme.textPrimary,
              ),
            ),
            const SizedBox(height: KainPHTheme.spacingMedium),
            _QuickAction(
              icon: Icons.shopping_cart_outlined,
              title: 'New Sale',
              onTap: () {},
            ),
            _QuickAction(
              icon: Icons.inventory_2_outlined,
              title: 'Add Stock',
              onTap: () {},
            ),
            _QuickAction(
              icon: Icons.person_add_alt_1_outlined,
              title: 'Add Customer',
              onTap: () {},
            ),
            _QuickAction(
              icon: Icons.receipt_long_outlined,
              title: 'Reprint Receipt',
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _StatCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(KainPHTheme.spacingMedium),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              icon,
              color: KainPHTheme.primary,
              size: 26,
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                color: KainPHTheme.textSecondary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: KainPHTheme.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _QuickAction({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        child: ListTile(
          onTap: onTap,
          leading: CircleAvatar(
            backgroundColor: KainPHTheme.primary.withOpacity(0.1),
            child: Icon(
              icon,
              color: KainPHTheme.primary,
            ),
          ),
          title: Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.w600,
            ),
          ),
          trailing: const Icon(Icons.chevron_right),
        ),
      ),
    );
  }
}
