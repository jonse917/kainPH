import 'package:flutter/material.dart';

import '../../core/services/tax_settings_store.dart';
import '../../core/theme/kainph_theme.dart';

class PosScreen extends StatefulWidget {
  const PosScreen({super.key});

  @override
  State<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends State<PosScreen> {
  final List<_Product> _products = const [
    _Product(
      id: 'burger',
      name: 'Classic Burger',
      category: 'Meals',
      price: 120,
      icon: Icons.lunch_dining,
    ),
    _Product(
      id: 'chicken',
      name: 'Chicken Meal',
      category: 'Meals',
      price: 150,
      icon: Icons.restaurant,
    ),
    _Product(
      id: 'pasta',
      name: 'Filipino Pasta',
      category: 'Meals',
      price: 130,
      icon: Icons.ramen_dining,
    ),
    _Product(
      id: 'fries',
      name: 'French Fries',
      category: 'Sides',
      price: 80,
      icon: Icons.fastfood,
    ),
    _Product(
      id: 'coke',
      name: 'Coke',
      category: 'Drinks',
      price: 40,
      icon: Icons.local_drink,
    ),
    _Product(
      id: 'coffee',
      name: 'Hot Coffee',
      category: 'Drinks',
      price: 90,
      icon: Icons.coffee,
    ),
    _Product(
      id: 'milkshake',
      name: 'Milkshake',
      category: 'Drinks',
      price: 110,
      icon: Icons.icecream,
    ),
    _Product(
      id: 'rice',
      name: 'Extra Rice',
      category: 'Sides',
      price: 30,
      icon: Icons.rice_bowl,
    ),
  ];

  final Map<String, int> _cart = {};

  String _selectedCategory = 'All';

  List<String> get _categories => [
        'All',
        ..._products.map((product) => product.category).toSet(),
      ];

  List<_Product> get _filteredProducts {
    if (_selectedCategory == 'All') {
      return _products;
    }

    return _products
        .where((product) => product.category == _selectedCategory)
        .toList();
  }

  double get _subtotal {
    double total = 0;

    for (final entry in _cart.entries) {
      final product = _products.firstWhere(
        (product) => product.id == entry.key,
      );

      total += product.price * entry.value;
    }

    return total;
  }

  int get _itemCount {
    return _cart.values.fold(
      0,
      (total, quantity) => total + quantity,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            if (constraints.maxWidth < 800) {
              return _buildPhoneLayout();
            }

            return _buildLargeLayout();
          },
        ),
      ),
    );
  }

  // ============================================================
  // PHONE LAYOUT
  // ============================================================

  Widget _buildPhoneLayout() {
    return Column(
      children: [
        _buildHeader(),
        _buildCategoryBar(),
        Expanded(
          child: _buildProductGrid(),
        ),
        _buildMobileCartBar(),
      ],
    );
  }

  Widget _buildMobileCartBar() {
    return Material(
      elevation: 8,
      color: Theme.of(context).cardColor,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  '$_itemCount item${_itemCount == 1 ? '' : 's'}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              Text(
                _formatCurrency(_subtotal),
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(width: 12),
              FilledButton(
                onPressed: _cart.isEmpty ? null : _showCartSheet,
                child: const Text('View Cart'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // LARGE LAYOUT
  // ============================================================

  Widget _buildLargeLayout() {
    return Column(
      children: [
        _buildHeader(),
        Expanded(
          child: Row(
            children: [
              Expanded(
                flex: 3,
                child: Column(
                  children: [
                    _buildCategoryBar(),
                    Expanded(
                      child: _buildProductGrid(),
                    ),
                  ],
                ),
              ),
              const VerticalDivider(width: 1),
              SizedBox(
                width: 360,
                child: _buildCartPanel(),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 12,
      ),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE5E7EB),
          ),
        ),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.point_of_sale,
            color: KainPHTheme.primary,
          ),
          const SizedBox(width: 10),
          const Text(
            'New Sale',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Spacer(),
          _orderTypeButton(),
        ],
      ),
    );
  }

  Widget _orderTypeButton() {
    return OutlinedButton.icon(
      onPressed: () {},
      icon: const Icon(Icons.restaurant_outlined),
      label: const Text('Dine In'),
    );
  }

  // ============================================================
  // CATEGORIES
  // ============================================================

  Widget _buildCategoryBar() {
    return SizedBox(
      height: 64,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 12,
        ),
        scrollDirection: Axis.horizontal,
        itemCount: _categories.length,
        separatorBuilder: (context, index) {
          return const SizedBox(width: 8);
        },
        itemBuilder: (context, index) {
          final category = _categories[index];
          final selected = category == _selectedCategory;

          return ChoiceChip(
            label: Text(category),
            selected: selected,
            onSelected: (_) {
              setState(() {
                _selectedCategory = category;
              });
            },
          );
        },
      ),
    );
  }

  // ============================================================
  // PRODUCTS
  // ============================================================

  Widget _buildProductGrid() {
    final products = _filteredProducts;

    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 220,
        mainAxisExtent: 190,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: products.length,
      itemBuilder: (context, index) {
        final product = products[index];

        return _ProductCard(
          product: product,
          onTap: () => _addToCart(product),
        );
      },
    );
  }

  // ============================================================
  // CART
  // ============================================================

  Widget _buildCartPanel() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              const Text(
                'Current Order',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              if (_cart.isNotEmpty)
                TextButton(
                  onPressed: _clearCart,
                  child: const Text('Clear'),
                ),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: _cart.isEmpty ? _buildEmptyCart() : _buildCartItems(),
        ),
        _buildCartSummary(),
      ],
    );
  }

  Widget _buildEmptyCart() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.shopping_cart_outlined,
              size: 56,
              color: KainPHTheme.textSecondary,
            ),
            SizedBox(height: 12),
            Text(
              'No items yet',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 4),
            Text(
              'Tap a product to add it to the order.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: KainPHTheme.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCartItems() {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: _cart.entries.map((entry) {
        final product = _products.firstWhere(
          (product) => product.id == entry.key,
        );

        return _CartItem(
          product: product,
          quantity: entry.value,
          onIncrease: () => _addToCart(product),
          onDecrease: () => _removeFromCart(product),
          onRemove: () => _removeProduct(product),
        );
      }).toList(),
    );
  }

  Widget _buildCartSummary() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        border: Border(
          top: BorderSide(
            color: Color(0xFFE5E7EB),
          ),
        ),
      ),
      child: Column(
        children: [
          _SummaryRow(
            label: 'Items',
            value: '$_itemCount',
          ),
          const SizedBox(height: 8),
          _SummaryRow(
            label: 'Subtotal',
            value: _formatCurrency(_subtotal),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: FilledButton(
              onPressed: _cart.isEmpty ? null : _showCheckoutSheet,
              child: Text(
                'PAY ${_formatCurrency(_subtotal)}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // CART ACTIONS
  // ============================================================

  void _addToCart(_Product product) {
    setState(() {
      _cart.update(
        product.id,
        (quantity) => quantity + 1,
        ifAbsent: () => 1,
      );
    });
  }

  void _removeFromCart(_Product product) {
    setState(() {
      final quantity = _cart[product.id] ?? 0;

      if (quantity <= 1) {
        _cart.remove(product.id);
      } else {
        _cart[product.id] = quantity - 1;
      }
    });
  }

  void _removeProduct(_Product product) {
    setState(() {
      _cart.remove(product.id);
    });
  }

  void _clearCart() {
    setState(() {
      _cart.clear();
    });
  }

  // ============================================================
  // MOBILE CART
  // ============================================================

  void _showCartSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) {
        return FractionallySizedBox(
          heightFactor: 0.85,
          child: _buildCartPanel(),
        );
      },
    );
  }

  // ============================================================
  // CHECKOUT
  // ============================================================

  void _showCheckoutSheet() {
    if (_cart.isEmpty) {
      return;
    }

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) {
        return _CheckoutSheet(
          subtotal: _subtotal,
          itemCount: _itemCount,
          onComplete: _completeSale,
        );
      },
    );
  }

  // ============================================================
  // COMPLETE SALE
  // ============================================================

  Future<void> _completeSale(
    String paymentMethod,
    String discountType,
    double cashReceived,
  ) async {
    final subtotal = _subtotal;
    final settings = TaxReceiptSettingsStore.current;

    final calculation = TaxCalculator.calculate(
      subtotal: subtotal,
      settings: settings,
      discountType: discountType,
    );

    if (paymentMethod == 'Cash' && cashReceived < calculation.totalAmount) {
      if (!mounted) {
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Insufficient cash received.'),
        ),
      );

      return;
    }

    final change =
        paymentMethod == 'Cash' ? cashReceived - calculation.totalAmount : 0.0;

    // Close checkout sheet.
    if (mounted) {
      Navigator.of(context).pop();
    }

    // Clear cart.
    if (mounted) {
      setState(() {
        _cart.clear();
      });
    }

    // Show success dialog after the checkout sheet is closed.
    if (!mounted) {
      return;
    }

    await _showSaleComplete(
      paymentMethod: paymentMethod,
      total: calculation.totalAmount,
      change: change,
      taxAmount: calculation.taxAmount,
      discountAmount: calculation.discountAmount,
      settings: settings,
    );
  }

  // ============================================================
  // SALE COMPLETE
  // ============================================================

  Future<void> _showSaleComplete({
    required String paymentMethod,
    required double total,
    required double change,
    required double taxAmount,
    required double discountAmount,
    required TaxReceiptSettings settings,
  }) async {
    if (!mounted) {
      return;
    }

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Row(
            children: [
              Icon(
                Icons.check_circle,
                color: KainPHTheme.primary,
              ),
              SizedBox(width: 10),
              Text('Sale Complete'),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SummaryRow(
                  label: 'Payment',
                  value: paymentMethod,
                ),

                if (discountAmount > 0) ...[
                  const SizedBox(height: 8),
                  _SummaryRow(
                    label: discountTypeLabel(discountAmount, settings),
                    value: '-${_formatCurrency(discountAmount)}',
                  ),
                ],

                // TAX IS OPTIONAL.
                //
                // Tax is shown only when:
                // 1. A tax amount actually exists.
                // 2. The user enabled "Show Tax on Receipt".
                if (settings.showTaxOnReceipt && taxAmount > 0) ...[
                  const SizedBox(height: 8),
                  _SummaryRow(
                    label: _taxLabel(settings),
                    value: _formatCurrency(taxAmount),
                  ),
                ],

                const SizedBox(height: 8),

                _SummaryRow(
                  label: 'Total',
                  value: _formatCurrency(total),
                ),

                if (paymentMethod == 'Cash') ...[
                  const SizedBox(height: 8),
                  _SummaryRow(
                    label: 'Change',
                    value: _formatCurrency(change),
                  ),
                ],

                const SizedBox(height: 16),

                Text(
                  settings.businessName,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),

                if (settings.tin.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    'TIN: ${settings.tin}',
                    style: const TextStyle(
                      color: KainPHTheme.textSecondary,
                    ),
                  ),
                ],

                if (settings.businessAddress.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      settings.businessAddress,
                      style: const TextStyle(
                        color: KainPHTheme.textSecondary,
                      ),
                    ),
                  ),

                const SizedBox(height: 12),

                Text(
                  settings.receiptFooter,
                  style: const TextStyle(
                    color: KainPHTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          actions: [
            FilledButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
              },
              child: const Text('Done'),
            ),
          ],
        );
      },
    );
  }
}

// ============================================================
// CHECKOUT SHEET
// ============================================================

class _CheckoutSheet extends StatefulWidget {
  final double subtotal;
  final int itemCount;

  final Future<void> Function(
    String paymentMethod,
    String discountType,
    double cashReceived,
  ) onComplete;

  const _CheckoutSheet({
    required this.subtotal,
    required this.itemCount,
    required this.onComplete,
  });

  @override
  State<_CheckoutSheet> createState() => _CheckoutSheetState();
}

class _CheckoutSheetState extends State<_CheckoutSheet> {
  final TextEditingController _cashController = TextEditingController();

  String _paymentMethod = 'Cash';
  String _discountType = 'None';

  bool _isCompleting = false;

  TaxReceiptSettings get _settings {
    return TaxReceiptSettingsStore.current;
  }

  TaxCalculation get _calculation {
    return TaxCalculator.calculate(
      subtotal: widget.subtotal,
      settings: _settings,
      discountType: _discountType,
    );
  }

  double get _discount {
    return _calculation.discountAmount;
  }

  double get _total {
    return _calculation.totalAmount;
  }

  double get _cashReceived {
    return double.tryParse(
          _cashController.text.trim(),
        ) ??
        0;
  }

  double get _change {
    final change = _cashReceived - _total;

    return change < 0 ? 0 : change;
  }

  bool get _canComplete {
    if (_isCompleting) {
      return false;
    }

    if (_paymentMethod != 'Cash') {
      return true;
    }

    return _cashReceived >= _total;
  }

  @override
  void dispose() {
    _cashController.dispose();
    super.dispose();
  }

  Future<void> _handleComplete() async {
    if (!_canComplete) {
      return;
    }

    setState(() {
      _isCompleting = true;
    });

    try {
      await widget.onComplete(
        _paymentMethod,
        _discountType,
        _cashReceived,
      );
    } finally {
      if (mounted) {
        setState(() {
          _isCompleting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final keyboardHeight = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.only(
        bottom: keyboardHeight,
      ),
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            8,
            20,
            20,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Checkout',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 4),

              Text(
                '${widget.itemCount} item${widget.itemCount == 1 ? '' : 's'}',
                style: const TextStyle(
                  color: KainPHTheme.textSecondary,
                ),
              ),

              const SizedBox(height: 20),

              // ==================================================
              // TOTAL
              // ==================================================

              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _SummaryRow(
                        label: 'Subtotal',
                        value: _formatCurrency(widget.subtotal),
                      ),

                      if (_discount > 0) ...[
                        const SizedBox(height: 8),
                        _SummaryRow(
                          label: 'Discount',
                          value: '-${_formatCurrency(_discount)}',
                        ),
                      ],

                      // ==================================================
                      // OPTIONAL TAX
                      // ==================================================
                      //
                      // No tax appears when:
                      // - Non-VAT
                      // - VAT Exempt
                      // - Tax rate is zero
                      //
                      // And even when tax exists, the receipt display
                      // setting can hide it.

                      if (_settings.showTaxOnReceipt &&
                          _calculation.taxAmount > 0) ...[
                        const SizedBox(height: 8),
                        _SummaryRow(
                          label: _taxLabel(_settings),
                          value: _formatCurrency(
                            _calculation.taxAmount,
                          ),
                        ),
                      ],

                      const Divider(height: 24),

                      Row(
                        children: [
                          const Text(
                            'TOTAL',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            _formatCurrency(_total),
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: KainPHTheme.primary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // ==================================================
              // DISCOUNT
              // ==================================================

              const Text(
                'Discount',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 8),

              Wrap(
                spacing: 8,
                children: [
                  _discountChip('None'),
                  if (_settings.enableSeniorPwdDiscount) ...[
                    _discountChip('Senior'),
                    _discountChip('PWD'),
                  ],
                ],
              ),

              const SizedBox(height: 20),

              // ==================================================
              // PAYMENT
              // ==================================================

              const Text(
                'Payment Method',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 8),

              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _paymentChip(
                    'Cash',
                    Icons.payments_outlined,
                  ),
                  _paymentChip(
                    'GCash',
                    Icons.phone_android,
                  ),
                  _paymentChip(
                    'Maya',
                    Icons.account_balance_wallet_outlined,
                  ),
                  _paymentChip(
                    'Card',
                    Icons.credit_card,
                  ),
                ],
              ),

              // ==================================================
              // CASH
              // ==================================================

              if (_paymentMethod == 'Cash') ...[
                const SizedBox(height: 20),
                TextField(
                  controller: _cashController,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  onChanged: (_) {
                    setState(() {});
                  },
                  decoration: const InputDecoration(
                    labelText: 'Cash Received',
                    prefixText: '₱ ',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                _SummaryRow(
                  label: 'Change',
                  value: _formatCurrency(_change),
                ),
              ],

              const SizedBox(height: 24),

              // ==================================================
              // COMPLETE SALE
              // ==================================================

              SizedBox(
                width: double.infinity,
                height: 54,
                child: FilledButton(
                  onPressed: _canComplete ? _handleComplete : null,
                  child: _isCompleting
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                          ),
                        )
                      : Text(
                          'COMPLETE SALE • ${_formatCurrency(_total)}',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _discountChip(String type) {
    return ChoiceChip(
      label: Text(type),
      selected: _discountType == type,
      onSelected: (_) {
        setState(() {
          _discountType = type;
        });
      },
    );
  }

  Widget _paymentChip(
    String method,
    IconData icon,
  ) {
    return ChoiceChip(
      avatar: Icon(
        icon,
        size: 18,
      ),
      label: Text(method),
      selected: _paymentMethod == method,
      onSelected: (_) {
        setState(() {
          _paymentMethod = method;
        });
      },
    );
  }
}

// ============================================================
// PRODUCT CARD
// ============================================================

class _ProductCard extends StatelessWidget {
  final _Product product;
  final VoidCallback onTap;

  const _ProductCard({
    required this.product,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: KainPHTheme.primary.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    product.icon,
                    size: 48,
                    color: KainPHTheme.primary,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                product.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                _formatCurrency(product.price),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: KainPHTheme.primary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// CART ITEM
// ============================================================

class _CartItem extends StatelessWidget {
  final _Product product;
  final int quantity;
  final VoidCallback onIncrease;
  final VoidCallback onDecrease;
  final VoidCallback onRemove;

  const _CartItem({
    required this.product,
    required this.quantity,
    required this.onIncrease,
    required this.onDecrease,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: KainPHTheme.primary.withOpacity(0.08),
              child: Icon(
                product.icon,
                color: KainPHTheme.primary,
                size: 20,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    _formatCurrency(product.price * quantity),
                    style: const TextStyle(
                      color: KainPHTheme.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            Row(
              children: [
                IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: onDecrease,
                  icon: const Icon(
                    Icons.remove_circle_outline,
                  ),
                ),
                Text(
                  '$quantity',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: onIncrease,
                  icon: const Icon(
                    Icons.add_circle_outline,
                  ),
                ),
              ],
            ),
            IconButton(
              visualDensity: VisualDensity.compact,
              onPressed: onRemove,
              icon: const Icon(
                Icons.delete_outline,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SUMMARY ROW
// ============================================================

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;

  const _SummaryRow({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: KainPHTheme.textSecondary,
          ),
        ),
        const Spacer(),
        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

// ============================================================
// PRODUCT MODEL
// ============================================================

class _Product {
  final String id;
  final String name;
  final String category;
  final double price;
  final IconData icon;

  const _Product({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    required this.icon,
  });
}

// ============================================================
// TAX LABEL
// ============================================================

String _taxLabel(TaxReceiptSettings settings) {
  switch (settings.taxProfile) {
    case TaxProfile.vatRegistered:
      return 'VAT ${settings.taxRate.toStringAsFixed(0)}%';

    case TaxProfile.custom:
      return 'Tax ${settings.taxRate.toStringAsFixed(0)}%';

    case TaxProfile.nonVat:
      return 'Tax';

    case TaxProfile.vatExempt:
      return 'Tax';
  }
}

// ============================================================
// DISCOUNT LABEL
// ============================================================
//
// Kept as a helper so the sale-complete dialog remains clean.

String discountTypeLabel(
  double discountAmount,
  TaxReceiptSettings settings,
) {
  if (discountAmount <= 0) {
    return 'Discount';
  }

  return 'Discount';
}

// ============================================================
// CURRENCY
// ============================================================

String _formatCurrency(double amount) {
  return '₱${amount.toStringAsFixed(2)}';
}
