import 'package:flutter/material.dart';
import '../../features/pos/pos_screen.dart';
import '../theme/kainph_theme.dart';
import '../../features/dashboard/dashboard_screen.dart';

class KainPHAppShell extends StatefulWidget {
  const KainPHAppShell({super.key});

  @override
  State<KainPHAppShell> createState() => _KainPHAppShellState();
}

class _KainPHAppShellState extends State<KainPHAppShell> {
  int _selectedIndex = 0;

  final List<_NavigationItem> _items = const [
    _NavigationItem(
      label: 'POS',
      icon: Icons.shopping_cart_outlined,
      selectedIcon: Icons.shopping_cart,
    ),
    _NavigationItem(
      label: 'Menu',
      icon: Icons.restaurant_menu_outlined,
      selectedIcon: Icons.restaurant_menu,
    ),
    _NavigationItem(
      label: 'Stock',
      icon: Icons.inventory_2_outlined,
      selectedIcon: Icons.inventory_2,
    ),
    _NavigationItem(
      label: 'Customers',
      icon: Icons.people_outline,
      selectedIcon: Icons.people,
    ),
    _NavigationItem(
      label: 'Marketing',
      icon: Icons.campaign_outlined,
      selectedIcon: Icons.campaign,
    ),
    _NavigationItem(
      label: 'Reports',
      icon: Icons.bar_chart_outlined,
      selectedIcon: Icons.bar_chart,
    ),
    _NavigationItem(
      label: 'Cashier',
      icon: Icons.point_of_sale_outlined,
      selectedIcon: Icons.point_of_sale,
    ),
    _NavigationItem(
      label: 'Settings',
      icon: Icons.settings_outlined,
      selectedIcon: Icons.settings,
    ),
  ];

  // Four important destinations shown on phones.
  final List<int> _phoneDestinations = const [0, 1, 2, 3];

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;

    if (width < 700) {
      return _buildPhoneLayout();
    }

    return _buildLargeLayout();
  }

  // ------------------------------------------------------------
  // PHONE
  // ------------------------------------------------------------

  Widget _buildPhoneLayout() {
    final isMoreSelected = _selectedIndex >= 4;

    return Scaffold(
      appBar: _buildAppBar(),
      body: _buildContent(),
      bottomNavigationBar: NavigationBar(
        selectedIndex:
            isMoreSelected ? 4 : _phoneDestinations.indexOf(_selectedIndex),
        onDestinationSelected: _onPhoneDestinationSelected,
        destinations: [
          ..._phoneDestinations.map(
            (index) => NavigationDestination(
              icon: Icon(_items[index].icon),
              selectedIcon: Icon(_items[index].selectedIcon),
              label: _items[index].label,
            ),
          ),
          NavigationDestination(
            icon: const Icon(Icons.more_horiz),
            selectedIcon: const Icon(Icons.more_horiz),
            label: 'More',
          ),
        ],
      ),
    );
  }

  void _onPhoneDestinationSelected(int index) {
    if (index < 4) {
      setState(() {
        _selectedIndex = _phoneDestinations[index];
      });
      return;
    }

    _showMoreMenu();
  }

  void _showMoreMenu() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) {
        return SafeArea(
          child: ListView(
            shrinkWrap: true,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(24, 8, 24, 12),
                child: Text(
                  'More',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              for (final index in [4, 5, 6, 7])
                ListTile(
                  leading: Icon(
                    _items[index].icon,
                    color: KainPHTheme.primary,
                  ),
                  title: Text(_items[index].label),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _selectedIndex = index;
                    });
                  },
                ),
            ],
          ),
        );
      },
    );
  }

  // ------------------------------------------------------------
  // TABLET / DESKTOP
  // ------------------------------------------------------------

  Widget _buildLargeLayout() {
    return Scaffold(
      body: Row(
        children: [
          _buildNavigationRail(),
          Expanded(
            child: Column(
              children: [
                _buildTopBar(),
                Expanded(
                  child: _buildContent(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationRail() {
    final isExtended = MediaQuery.sizeOf(context).width >= 1000;

    return NavigationRail(
      selectedIndex: _selectedIndex,
      onDestinationSelected: _selectPage,
      extended: isExtended,
      labelType: isExtended
          ? NavigationRailLabelType.none
          : NavigationRailLabelType.all,
      leading: const Padding(
        padding: EdgeInsets.symmetric(vertical: 20),
        child: Text(
          '🍴',
          style: TextStyle(fontSize: 28),
        ),
      ),
      destinations: _items
          .map(
            (item) => NavigationRailDestination(
              icon: Icon(item.icon),
              selectedIcon: Icon(item.selectedIcon),
              label: Text(item.label),
            ),
          )
          .toList(),
    );
  }

  // ------------------------------------------------------------
  // TOP BAR
  // ------------------------------------------------------------

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: const Text(
        '🍴 KainPH',
        style: TextStyle(
          fontWeight: FontWeight.bold,
        ),
      ),
      actions: [
        _offlineBadge(),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildTopBar() {
    return Container(
      height: 72,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        border: const Border(
          bottom: BorderSide(
            color: Color(0xFFE5E7EB),
          ),
        ),
      ),
      child: Row(
        children: [
          const Text(
            'KainPH POS',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: KainPHTheme.textPrimary,
            ),
          ),
          const Spacer(),
          _offlineBadge(),
          const SizedBox(width: 16),
          const CircleAvatar(
            radius: 18,
            child: Icon(Icons.person_outline),
          ),
        ],
      ),
    );
  }

  Widget _offlineBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: KainPHTheme.success.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.cloud_off,
            size: 16,
            color: KainPHTheme.success,
          ),
          SizedBox(width: 6),
          Text(
            'Offline',
            style: TextStyle(
              color: KainPHTheme.success,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------
  // CONTENT
  // ------------------------------------------------------------

  Widget _buildContent() {
    switch (_selectedIndex) {
      case 0:
        return const PosScreen();

      case 1:
        return const _PlaceholderPage(
          title: 'Menu',
          icon: Icons.restaurant_menu,
          description: 'Manage products and categories.',
        );

      case 2:
        return const _PlaceholderPage(
          title: 'Inventory',
          icon: Icons.inventory_2,
          description: 'Track stock, ingredients, and movements.',
        );

      case 3:
        return const _PlaceholderPage(
          title: 'Customers',
          icon: Icons.people,
          description: 'Manage customers and loyalty.',
        );

      case 4:
        return const _PlaceholderPage(
          title: 'Marketing',
          icon: Icons.campaign,
          description: 'Promotions, coupons, and campaigns.',
        );

      case 5:
        return const DashboardScreen();

      case 6:
        return const _PlaceholderPage(
          title: 'Cashier',
          icon: Icons.point_of_sale,
          description: 'Manage cashier sessions and cash.',
        );

      case 7:
        return const _PlaceholderPage(
          title: 'Settings',
          icon: Icons.settings,
          description: 'Configure your KainPH POS.',
        );

      default:
        return const DashboardScreen();
    }
  }

  void _selectPage(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
}

// ------------------------------------------------------------
// NAVIGATION ITEM
// ------------------------------------------------------------

class _NavigationItem {
  final String label;
  final IconData icon;
  final IconData selectedIcon;

  const _NavigationItem({
    required this.label,
    required this.icon,
    required this.selectedIcon,
  });
}

// ------------------------------------------------------------
// PLACEHOLDER SCREEN
// ------------------------------------------------------------

class _PlaceholderPage extends StatelessWidget {
  final String title;
  final IconData icon;
  final String description;

  const _PlaceholderPage({
    required this.title,
    required this.icon,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 64,
              color: KainPHTheme.primary,
            ),
            const SizedBox(height: 20),
            Text(
              title,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              description,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: KainPHTheme.textSecondary,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
