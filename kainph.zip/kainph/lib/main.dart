import 'package:flutter/material.dart';

import 'core/theme/kainph_theme.dart';
import 'core/widgets/app_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(const KainPHApp());
}

class KainPHApp extends StatelessWidget {
  const KainPHApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KainPH POS',
      theme: KainPHTheme.light(),
      home: const KainPHAppShell(),
    );
  }
}
